import speech_recognition as sr
import pyttsx3
import pandas as pd
import random
from datetime import datetime, timedelta
import json
import os

class VoiceAssistant:
    def __init__(self):
        self.health_data = self.load_health_data()
        self.conversation_history = []
        
    def load_health_data(self):
        """Load health education data"""
        try:
            return pd.read_csv("data/health_data.csv")
        except:
            return pd.DataFrame()
    
    def speak(self, text, language='en'):
        """
        Converts text to speech with language support.
        """
        try:
            engine = pyttsx3.init()
            engine.setProperty('rate', 150)  # Slower for better understanding
            
            # Set voice properties for better clarity
            voices = engine.getProperty('voices')
            if voices:
                # Use a female voice if available (often clearer)
                for voice in voices:
                    if 'female' in voice.name.lower() or 'zira' in voice.name.lower():
                        engine.setProperty('voice', voice.id)
                        break
            
            engine.say(text)
            engine.runAndWait()
        except Exception as e:
            print(f"🔈 (Text mode) {text}")
    
    def listen(self, timeout=5):
        """
        Listens to the user's voice and converts it to text.
        Falls back to text input if microphone isn't available.
        """
        recognizer = sr.Recognizer()
        
        try:
            with sr.Microphone() as source:
                print("🎤 Listening... Speak now.")
                recognizer.adjust_for_ambient_noise(source, duration=1)
                audio = recognizer.listen(source, timeout=timeout)

            try:
                # Try English first, then Hindi
                query = recognizer.recognize_google(audio, language='en-IN')
                print(f"🗣 You said: {query}")
                return query.lower()

            except sr.UnknownValueError:
                print("❌ Sorry, I couldn't understand. Please repeat.")
                self.speak("Sorry, I couldn't understand. Please repeat.")
                return ""

            except sr.RequestError:
                print("⚠️ Network issue. Try again later.")
                self.speak("Network issue. Try again later.")
                return ""

        except Exception as e:
            # Fallback to text input
            print("🎤 Microphone not available or PyAudio not installed.")
            print("👉 Switching to text input mode.")
            query = input("Type your query: ")
            return query.lower()
    
    def process_query(self, query):
        """
        Process user queries and provide appropriate responses.
        """
        query = query.lower().strip()
        self.conversation_history.append({"user": query, "timestamp": datetime.now()})
        
        # Health tips and education
        if any(word in query for word in ['tip', 'advice', 'help', 'suggestion']):
            return self.get_random_health_tip()
        
        # BMI calculation
        elif any(word in query for word in ['bmi', 'weight', 'height']):
            return "To calculate BMI, I need your height and weight. Please use the form above to enter your details."
        
        # Water intake
        elif any(word in query for word in ['water', 'drink', 'hydration']):
            return "Drink at least 8 glasses or 2-3 liters of water daily. This helps maintain good health and prevents dehydration."
        
        # Vaccination
        elif any(word in query for word in ['vaccine', 'vaccination', 'injection']):
            return "Vaccines protect you from dangerous diseases. Children should get vaccines at birth, 6 weeks, 10 weeks, 14 weeks, 9 months, and 16 months."
        
        # Hygiene
        elif any(word in query for word in ['hygiene', 'clean', 'wash', 'sanitation']):
            return "Wash hands with soap before eating and after using toilet. Keep surroundings clean and use mosquito nets at night."
        
        # Nutrition
        elif any(word in query for word in ['food', 'eat', 'nutrition', 'diet']):
            return "Eat balanced meals with dal, green vegetables, fruits, and milk. Avoid junk food and maintain regular meal times."
        
        # General health
        elif any(word in query for word in ['health', 'healthy', 'fitness']):
            return "Stay healthy by eating nutritious food, drinking clean water, maintaining hygiene, and getting regular exercise."
        
        # Greeting
        elif any(word in query for word in ['hello', 'hi', 'namaste', 'good morning', 'good evening']):
            greetings = [
                "Hello! I'm your health assistant. How can I help you today?",
                "Namaste! I'm here to help with your health questions.",
                "Good to see you! Ask me anything about health and wellness."
            ]
            return random.choice(greetings)
        
        # Default response
        else:
            return "I can help you with health tips, BMI calculation, vaccination schedules, nutrition advice, and hygiene tips. What would you like to know?"
    
    def get_random_health_tip(self):
        """Get a random health tip from the database"""
        try:
            if not self.health_data.empty and 'answer' in self.health_data.columns:
                tips = self.health_data['answer'].dropna().tolist()
                return random.choice(tips)
            else:
                return "Eat fresh fruits and vegetables daily, drink clean water, and maintain good hygiene for better health."
        except:
            return "Stay healthy by eating nutritious food, drinking clean water, and maintaining hygiene."
    
    def get_reminder_message(self, name, reminder_type, date):
        """Generate personalized reminder messages"""
        messages = {
            'vaccination': f"Hello {name}! This is a reminder that your vaccination is due on {date}. Please visit your local health center.",
            'checkup': f"Hello {name}! Your health checkup is scheduled for {date}. Don't forget to visit the health worker.",
            'water': f"Hello {name}! Remember to drink enough water today. Aim for 8 glasses to stay healthy.",
            'exercise': f"Hello {name}! Time for some light exercise. A 15-minute walk can improve your health."
        }
        return messages.get(reminder_type, f"Hello {name}! This is a health reminder for {date}.")

# Create global instance
voice_assistant = VoiceAssistant()

# Backward compatibility functions
def speak(text):
    voice_assistant.speak(text)

def listen():
    return voice_assistant.listen()

def process_voice_query(query):
    return voice_assistant.process_query(query)
