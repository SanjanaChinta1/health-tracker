from datetime import timedelta, datetime, date
import pandas as pd
import json
import os

def calculate_bmi(height_cm, weight_kg):
    height_m = height_cm / 100
    bmi = weight_kg / (height_m ** 2)
    if bmi < 18.5:
        status = "Underweight"
    elif 18.5 <= bmi < 24.9:
        status = "Normal"
    elif 25 <= bmi < 29.9:
        status = "Overweight"
    else:
        status = "Obese"
    return bmi, status

def get_health_tip(status):
    tips = {
        "Underweight": "Eat protein-rich foods like eggs, milk, and pulses. Include nuts and dried fruits in your diet.",
        "Normal": "Maintain your routine and include fruits & vegetables daily. Keep up the good work!",
        "Overweight": "Reduce fried foods and increase physical activity. Try walking for 30 minutes daily.",
        "Obese": "Consult a health worker; start light exercise and eat fiber-rich foods. Focus on gradual weight loss."
    }
    return tips.get(status, "Drink clean water and maintain hygiene daily.")

def get_local_language_health_tips(status, language="hindi"):
    """Get health tips in local language based on BMI status"""
    hindi_tips = {
        "Underweight": {
            "nutrition": "कम वजन वालों के लिए: रोजाना अंडे, दूध, दाल और मेवे खाएं। हरी सब्जियां और फल भी जरूर खाएं।",
            "exercise": "हल्का व्यायाम करें और पर्याप्त आराम करें।",
            "general": "नियमित भोजन करें और स्वच्छ पानी पिएं।"
        },
        "Normal": {
            "nutrition": "स्वस्थ वजन बनाए रखने के लिए: संतुलित आहार लें, हरी सब्जियां और फल खाएं।",
            "exercise": "रोजाना 30 मिनट टहलें या हल्का व्यायाम करें।",
            "general": "अच्छा काम कर रहे हैं! इसी तरह स्वस्थ रहें।"
        },
        "Overweight": {
            "nutrition": "वजन कम करने के लिए: तली हुई चीजें कम खाएं, हरी सब्जियां और फल ज्यादा खाएं।",
            "exercise": "रोजाना 45 मिनट टहलें या व्यायाम करें।",
            "general": "धीरे-धीरे वजन कम करें, जल्दबाजी न करें।"
        },
        "Obese": {
            "nutrition": "मोटापा कम करने के लिए: डॉक्टर से सलाह लें, फाइबर वाली चीजें खाएं।",
            "exercise": "हल्का व्यायाम शुरू करें और धीरे-धीरे बढ़ाएं।",
            "general": "तुरंत स्वास्थ्य कार्यकर्ता से मिलें और नियमित जांच करवाएं।"
        }
    }
    
    english_tips = {
        "Underweight": {
            "nutrition": "For underweight: Eat protein-rich foods like eggs, milk, pulses, nuts and dried fruits daily.",
            "exercise": "Do light exercise and get adequate rest.",
            "general": "Eat regular meals and drink clean water."
        },
        "Normal": {
            "nutrition": "To maintain healthy weight: Eat balanced diet with green vegetables and fruits.",
            "exercise": "Walk for 30 minutes daily or do light exercise.",
            "general": "Great job! Keep maintaining your health like this."
        },
        "Overweight": {
            "nutrition": "To reduce weight: Eat less fried foods, more green vegetables and fruits.",
            "exercise": "Walk for 45 minutes daily or do exercise.",
            "general": "Reduce weight gradually, don't rush."
        },
        "Obese": {
            "nutrition": "To reduce obesity: Consult a doctor, eat fiber-rich foods.",
            "exercise": "Start with light exercise and gradually increase.",
            "general": "Visit health worker immediately and get regular checkups."
        }
    }
    
    tips_dict = hindi_tips if language == "hindi" else english_tips
    return tips_dict.get(status, {
        "nutrition": "संतुलित आहार लें और स्वच्छ पानी पिएं।" if language == "hindi" else "Eat balanced diet and drink clean water.",
        "exercise": "नियमित व्यायाम करें।" if language == "hindi" else "Exercise regularly.",
        "general": "अच्छी स्वच्छता बनाए रखें।" if language == "hindi" else "Maintain good hygiene."
    })

def next_vaccine_date(last_vaccine_date):
    return last_vaccine_date + timedelta(days=180)  # next vaccine after ~6 months

def get_vaccination_schedule(age_months):
    """Get vaccination schedule based on age"""
    schedules = {
        "birth": ["BCG", "Hepatitis B", "OPV"],
        "6_weeks": ["DPT", "Hepatitis B", "OPV", "PCV"],
        "10_weeks": ["DPT", "Hepatitis B", "OPV", "PCV"],
        "14_weeks": ["DPT", "Hepatitis B", "OPV", "PCV"],
        "9_months": ["Measles", "OPV"],
        "16_months": ["DPT", "Measles", "OPV"]
    }
    
    if age_months == 0:
        return schedules["birth"]
    elif age_months <= 6:
        return schedules["6_weeks"]
    elif age_months <= 10:
        return schedules["10_weeks"]
    elif age_months <= 14:
        return schedules["14_weeks"]
    elif age_months <= 16:
        return schedules["9_months"]
    else:
        return schedules["16_months"]

def calculate_age_in_months(birth_date):
    """Calculate age in months from birth date"""
    today = date.today()
    age_years = today.year - birth_date.year
    age_months = age_years * 12 + (today.month - birth_date.month)
    return age_months

def get_water_intake_recommendation(age, weight, activity_level="moderate"):
    """Get personalized water intake recommendation"""
    base_intake = {
        "children": 4,  # glasses
        "adults": 8,    # glasses
        "elderly": 6    # glasses
    }
    
    if age < 18:
        category = "children"
    elif age > 65:
        category = "elderly"
    else:
        category = "adults"
    
    glasses = base_intake[category]
    
    # Adjust for activity level
    if activity_level == "high":
        glasses += 2
    elif activity_level == "low":
        glasses -= 1
    
    return max(4, glasses)  # Minimum 4 glasses

def create_reminder(name, reminder_type, due_date, description=""):
    """Create a health reminder"""
    reminder = {
        "id": f"{name}_{reminder_type}_{due_date}",
        "name": name,
        "type": reminder_type,
        "due_date": due_date,
        "description": description,
        "created_date": datetime.now().isoformat(),
        "completed": False
    }
    return reminder

def save_reminder(reminder):
    """Save reminder to file"""
    reminders_file = "data/reminders.json"
    
    # Load existing reminders
    if os.path.exists(reminders_file):
        with open(reminders_file, 'r') as f:
            reminders = json.load(f)
    else:
        reminders = []
    
    # Add new reminder
    reminders.append(reminder)
    
    # Save back to file
    with open(reminders_file, 'w') as f:
        json.dump(reminders, f, indent=2)

def get_upcoming_reminders(days_ahead=7):
    """Get reminders due in the next few days"""
    reminders_file = "data/reminders.json"
    
    if not os.path.exists(reminders_file):
        return []
    
    with open(reminders_file, 'r') as f:
        reminders = json.load(f)
    
    today = date.today()
    upcoming = []
    
    for reminder in reminders:
        if not reminder.get("completed", False):
            due_date = datetime.fromisoformat(reminder["due_date"]).date()
            days_until = (due_date - today).days
            
            if 0 <= days_until <= days_ahead:
                reminder["days_until"] = days_until
                upcoming.append(reminder)
    
    return sorted(upcoming, key=lambda x: x["days_until"])

def get_health_score(bmi_status, water_intake, last_checkup_days):
    """Calculate overall health score (0-100)"""
    score = 50  # Base score
    
    # BMI contribution
    if bmi_status == "Normal":
        score += 20
    elif bmi_status in ["Underweight", "Overweight"]:
        score += 10
    else:  # Obese
        score += 0
    
    # Water intake contribution
    if water_intake >= 8:
        score += 15
    elif water_intake >= 6:
        score += 10
    elif water_intake >= 4:
        score += 5
    
    # Recent checkup contribution
    if last_checkup_days <= 90:  # Within 3 months
        score += 15
    elif last_checkup_days <= 180:  # Within 6 months
        score += 10
    elif last_checkup_days <= 365:  # Within 1 year
        score += 5
    
    return min(100, max(0, score))

def get_local_language_tips(language="hindi"):
    """Get health tips in local language"""
    hindi_tips = {
        "nutrition": "रोजाना दाल, हरी सब्जियां, फल और दूध खाएं। जंक फूड से बचें।",
        "hygiene": "खाने से पहले और शौचालय के बाद साबुन से हाथ धोएं।",
        "water": "रोजाना कम से कम 8 गिलास पानी पिएं।",
        "exercise": "रोजाना 30 मिनट टहलें या हल्का व्यायाम करें।",
        "vaccination": "बच्चों को समय पर टीके लगवाएं। यह खतरनाक बीमारियों से बचाता है।"
    }
    
    return hindi_tips if language == "hindi" else {}
