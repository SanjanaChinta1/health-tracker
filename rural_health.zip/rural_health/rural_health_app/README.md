# Rural Health Tracker & Awareness App

A comprehensive health monitoring application designed specifically for rural communities, featuring voice assistance and local language support.

## Features

### 🏥 Core Health Features
- **BMI Calculator**: Calculate BMI with personalized health tips in English/Hindi
- **Family Health Management**: Track health data for multiple family members
- **Health Score**: Overall health assessment based on BMI, water intake, and checkup history
- **Vaccination Tracking**: Schedule and reminders for vaccinations
- **Water Intake Monitoring**: Personalized water intake recommendations

### 🎙️ Voice Assistant
- Interactive voice assistant for health queries
- Support for English and Hindi languages
- Voice-based health tips and advice
- Conversational health education

### 🔔 Smart Reminders
- Personalized reminders for vaccinations, checkups, and health activities
- Visual urgency indicators (red/yellow/green)
- Customizable reminder types

### 🎓 Health Education
- Comprehensive Q&A database covering nutrition, hygiene, vaccination, and general health
- Local language support (Hindi)
- Category-based health tips
- Preventive healthcare awareness

### 📊 Analytics & Trends
- Health trend visualization
- Family health comparisons
- BMI distribution charts
- Water intake tracking

## Installation

1. Install Python dependencies:
```bash
pip install -r requirements.txt
```

2. Run the application:
```bash
streamlit run app.py
```

## Usage

### BMI Calculator
1. Navigate to "⚖️ BMI Calculator"
2. Select your preferred language (English/Hindi)
3. Enter your height, weight, age, and activity level
4. Get personalized health tips and recommendations
5. Save results to Family Health section

### Voice Assistant
1. Go to "🎙️ Voice Assistant"
2. Click "Start Listening" and speak your health question
3. Get instant voice responses in your preferred language

### Family Health Management
1. Add family members through the Health Dashboard or BMI Calculator
2. View family health overview and individual member details
3. Track vaccination schedules for children
4. Monitor health trends over time

## Key Benefits for Rural Communities

- **Accessibility**: Voice-based interaction for users with limited literacy
- **Local Language Support**: Hindi language support for better understanding
- **Preventive Focus**: Emphasis on preventive healthcare and awareness
- **Family-Centric**: Designed for family health management
- **Offline Capable**: Works without constant internet connection
- **Simple Interface**: Easy-to-use design suitable for all age groups

## Health Tips Categories

- **Nutrition**: Balanced diet recommendations with local food suggestions
- **Hygiene**: Hand washing, sanitation, and cleanliness practices
- **Vaccination**: Complete vaccination schedules for children and adults
- **General Health**: Water intake, exercise, and lifestyle recommendations
- **Awareness**: Disease prevention and health promotion

## Technical Requirements

- Python 3.7+
- Microphone (for voice features)
- Speakers/headphones (for voice output)
- Modern web browser

## Contributing

This app is designed to improve healthcare access in rural areas. Contributions are welcome to:
- Add more local languages
- Expand health education content
- Improve voice recognition accuracy
- Add more health indicators

## License

Built with ❤️ for rural communities to promote preventive healthcare and awareness.
