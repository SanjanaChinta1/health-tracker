import speech_recognition as sr

r = sr.Recognizer()
try:
    mic = sr.Microphone()
    print("🎤 Microphone found:", mic.list_microphone_names())
    with mic as source:
        print("Say something...")
        r.adjust_for_ambient_noise(source)
        audio = r.listen(source)
    print("✅ Audio captured successfully!")
except Exception as e:
    print("❌ Error:", e)
    print("👉 Microphone not available or PyAudio not installed. Please ensure PyAudio is installed and a microphone is connected.")