import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from datetime import datetime, date, timedelta
import json
import os
from utils.health_utils import (
    calculate_bmi, get_health_tip, next_vaccine_date, 
    get_vaccination_schedule, calculate_age_in_months,
    get_water_intake_recommendation, create_reminder, save_reminder,
    get_upcoming_reminders, get_health_score, get_local_language_tips,
    get_local_language_health_tips
)
from utils.voice_assistant import voice_assistant, process_voice_query

# Page configuration
st.set_page_config(
    page_title="Rural Health Tracker", 
    page_icon="⚕️", 
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for better styling
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(90deg, #4CAF50, #45a049);
        padding: 1rem;
        border-radius: 10px;
        color: white;
        text-align: center;
        margin-bottom: 2rem;
    }
    .metric-card {
        background: white;
        padding: 1rem;
        border-radius: 10px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        border-left: 4px solid #4CAF50;
    }
    .reminder-card {
        background: #fff3cd;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #ffc107;
        margin: 0.5rem 0;
    }
    .health-tip {
        background: #d1ecf1;
        padding: 1rem;
        border-radius: 8px;
        border-left: 4px solid #17a2b8;
    }
    .voice-section {
        background: #f8f9fa;
        padding: 1.5rem;
        border-radius: 10px;
        border: 2px dashed #6c757d;
    }
</style>
""", unsafe_allow_html=True)

# Main header
st.markdown("""
<div class="main-header">
    <h1>⚕️ Rural Health Tracker & Awareness App</h1>
    <p>Empowering rural families with preventive health awareness 💚</p>
</div>
""", unsafe_allow_html=True)

# Sidebar for navigation
st.sidebar.title("🏠 Navigation")
page = st.sidebar.selectbox("Choose a section:", [
    "📊 Health Dashboard", 
    "⚖️ BMI Calculator",
    "👨‍👩‍👧‍👦 Family Health", 
    "🔔 Reminders", 
    "🎓 Health Education", 
    "🎙️ Voice Assistant",
    "📈 Health Trends"
])

# Initialize session state
if 'family_members' not in st.session_state:
    st.session_state.family_members = []

if 'current_member' not in st.session_state:
    st.session_state.current_member = None

# Health Dashboard Page
if page == "📊 Health Dashboard":
    st.header("📊 Health Dashboard")
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("👥 Family Members", len(st.session_state.family_members))
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col2:
        upcoming_reminders = get_upcoming_reminders(7)
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("🔔 Upcoming Reminders", len(upcoming_reminders))
        st.markdown('</div>', unsafe_allow_html=True)
    
    with col3:
        st.markdown('<div class="metric-card">', unsafe_allow_html=True)
        st.metric("📅 Today", date.today().strftime("%B %d, %Y"))
        st.markdown('</div>', unsafe_allow_html=True)
    
    # Quick health form
    st.subheader("📝 Quick Health Check")

# ✅ Start form properly
with st.form("quick_health_form"):
    col1, col2 = st.columns(2)

    with col1:
        name = st.text_input("Full Name", placeholder="Enter your name")
        age = st.number_input("Age", min_value=1, max_value=120, step=1)
        gender = st.selectbox("Gender", ["Male", "Female", "Other"])

    with col2:
        height = st.number_input("Height (cm)", min_value=50.0, max_value=250.0, value=160.0)
        weight = st.number_input("Weight (kg)", min_value=10.0, max_value=200.0, value=60.0)

    water_intake = st.slider("Daily Water Intake (glasses)", 0, 15, 8)
    last_checkup = st.date_input("Last Health Checkup", value=date.today() - timedelta(days=90))

    # ✅ Submit button inside form
    submit = st.form_submit_button("📊 Calculate Health Score", use_container_width=True)

# ✅ Form submission logic outside the form
if submit and name:
    bmi, status = calculate_bmi(height, weight)
    health_score = get_health_score(status, water_intake, (date.today() - last_checkup).days)
    recommended_water = get_water_intake_recommendation(age, weight)

    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.success(f"**BMI:** {bmi:.2f} ({status})")
    with col2:
        st.info(f"**Health Score:** {health_score}/100")
    with col3:
        st.warning(f"**Recommended Water:** {recommended_water} glasses")

    # Health tip
    st.subheader("🌍 Health Tips in Local Language")
    language = st.selectbox("Select Language", ["English", "Hindi"])
    
    # ✅ Use the correct function name that you actually defined
    tips = get_local_language_health_tips(status, language.lower())

    col1, col2 = st.columns(2)
    with col1:
        st.markdown(f"### 🍎 Nutrition Tip:\n{tips['nutrition']}")
        st.markdown(f"💪 Exercise Tip:\n{tips['exercise']}")
    with col2:
        st.markdown(f"💧 General Advice:\n{tips['general']}")
        
        # Save to family members
    member_data = {
            "name": name,
            "age": age,
            "gender": gender,
            "height": height,
            "weight": weight,
            "bmi": bmi,
            "status": status,
            "water_intake": water_intake,
            "last_checkup": last_checkup,
            "health_score": health_score,
            "date_added": datetime.now().isoformat()
        }
        
        # Check if member already exists
    existing_member = next((m for m in st.session_state.family_members if m["name"] == name), None)
    if existing_member:
            st.session_state.family_members.remove(existing_member)
        
    st.session_state.family_members.append(member_data)
    st.success("✅ Health data saved!")

# BMI Calculator Page
elif page == "⚖️ BMI Calculator":
    st.header("⚖️ BMI & Health Indicator Calculator")
    st.write("Calculate your BMI and get personalized health tips in your preferred language")
    
    # Language selection
    col1, col2 = st.columns([1, 3])
    with col1:
        language = st.selectbox("🌍 Language", ["English", "Hindi"])
    with col2:
        st.info("💡 Choose your preferred language for health tips and recommendations")
    
    # BMI Calculator Form
    st.subheader("📏 Enter Your Details")
    
    with st.form("bmi_calculator_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            name = st.text_input("👤 Full Name", placeholder="Enter your name")
            age = st.number_input("🎂 Age (years)", min_value=1, max_value=120, step=1, value=25)
            gender = st.selectbox("👥 Gender", ["Male", "Female", "Other"])
        
        with col2:
            height = st.number_input("📏 Height (cm)", min_value=50.0, max_value=250.0, value=160.0, step=0.1)
            weight = st.number_input("⚖️ Weight (kg)", min_value=10.0, max_value=200.0, value=60.0, step=0.1)
            activity_level = st.selectbox("🏃 Activity Level", ["Low", "Moderate", "High"])
        
        submit_bmi = st.form_submit_button("🧮 Calculate BMI & Health Score", use_container_width=True)
    
    if submit_bmi and name:
        # Calculate BMI and health indicators
        bmi, status = calculate_bmi(height, weight)
        health_score = get_health_score(status, 8, 90)  # Default values for demo
        recommended_water = get_water_intake_recommendation(age, weight, activity_level.lower())
        
        # Display results
        st.success(f"✅ **{name}'s Health Results**")
        
        # BMI Results
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.metric("📊 BMI", f"{bmi:.2f}")
            st.write(f"**Status:** {status}")
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col2:
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.metric("💧 Recommended Water", f"{recommended_water} glasses/day")
            st.write(f"**Activity:** {activity_level}")
            st.markdown('</div>', unsafe_allow_html=True)
        
        with col3:
            st.markdown('<div class="metric-card">', unsafe_allow_html=True)
            st.metric("⭐ Health Score", f"{health_score}/100")
            st.write(f"**Age:** {age} years")
            st.markdown('</div>', unsafe_allow_html=True)
        
        # BMI Status with Color Coding
        st.subheader("📊 BMI Analysis")
        
        if status == "Underweight":
            st.warning("⚠️ **Underweight** - You may need to gain some weight for optimal health.")
        elif status == "Normal":
            st.success("✅ **Healthy Weight** - Great! You're maintaining a healthy weight.")
        elif status == "Overweight":
            st.warning("⚠️ **Overweight** - Consider making some lifestyle changes.")
        else:  # Obese
            st.error("🚨 **Obese** - Please consult a health worker for guidance.")
        
        # Health Tips Section
        st.subheader("💡 Personalized Health Tips")
        
        # Get tips based on language preference
        lang_code = "hindi" if language == "Hindi" else "english"
        tips = get_local_language_health_tips(status, lang_code)
        
        # Display tips in tabs
        tab1, tab2, tab3 = st.tabs(["🍎 Nutrition", "🏃 Exercise", "💡 General"])
        
        with tab1:
            st.markdown(f'<div class="health-tip"><strong>🍎 Nutrition Tips:</strong><br>{tips["nutrition"]}</div>', unsafe_allow_html=True)
        
        with tab2:
            st.markdown(f'<div class="health-tip"><strong>🏃 Exercise Tips:</strong><br>{tips["exercise"]}</div>', unsafe_allow_html=True)
        
        with tab3:
            st.markdown(f'<div class="health-tip"><strong>💡 General Tips:</strong><br>{tips["general"]}</div>', unsafe_allow_html=True)
        
        # Additional Recommendations
        st.subheader("📋 Additional Recommendations")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**🎯 Immediate Actions:**")
            if status == "Underweight":
                st.write("• Eat protein-rich foods daily")
                st.write("• Include nuts and dried fruits")
                st.write("• Get adequate rest")
            elif status == "Normal":
                st.write("• Maintain current healthy habits")
                st.write("• Continue regular exercise")
                st.write("• Keep balanced diet")
            elif status == "Overweight":
                st.write("• Reduce portion sizes")
                st.write("• Increase physical activity")
                st.write("• Limit fried foods")
            else:  # Obese
                st.write("• Consult health worker immediately")
                st.write("• Start with light exercise")
                st.write("• Focus on gradual changes")
        
        with col2:
            st.write("**📅 Follow-up Schedule:**")
            if status in ["Overweight", "Obese"]:
                st.write("• Weekly weight check")
                st.write("• Monthly health review")
                st.write("• 3-month doctor visit")
            else:
                st.write("• Monthly weight check")
                st.write("• Quarterly health review")
                st.write("• Annual doctor visit")
        
        # Voice Assistant Integration
        st.subheader("🎙️ Voice Assistant")
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔊 Listen to Health Tips", use_container_width=True):
                tip_text = f"{name}, your BMI is {bmi:.2f}, which means you are {status}. {tips['general']}"
                voice_assistant.speak(tip_text)
        
        with col2:
            if st.button("🎤 Ask Health Questions", use_container_width=True):
                st.info("🎤 Listening... Ask any health question!")
                user_query = voice_assistant.listen()
                if user_query:
                    response = process_voice_query(user_query)
                    st.write(f"**Assistant:** {response}")
        
        # Save to family members option
        st.subheader("💾 Save Results")
        if st.button("💾 Save to Family Health", use_container_width=True):
            member_data = {
                "name": name,
                "age": age,
                "gender": gender,
                "height": height,
                "weight": weight,
                "bmi": bmi,
                "status": status,
                "water_intake": recommended_water,
                "last_checkup": date.today(),
                "health_score": health_score,
                "date_added": datetime.now().isoformat()
            }
            
            # Check if member already exists
            existing_member = next((m for m in st.session_state.family_members if m["name"] == name), None)
            if existing_member:
                st.session_state.family_members.remove(existing_member)
            
            st.session_state.family_members.append(member_data)
            st.success("✅ Health data saved to Family Health section!")
    
    elif calculate_bmi and not name:
        st.error("❌ Please enter your name to calculate BMI.")

# Family Health Page
elif page == "👨‍👩‍👧‍👦 Family Health":
    st.header("👨‍👩‍👧‍👦 Family Health Management")
    
    if st.session_state.family_members:
        # Family overview
        st.subheader("👥 Family Overview")
        
        # Create family dataframe
        family_df = pd.DataFrame(st.session_state.family_members)
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Family health summary
            avg_health_score = family_df['health_score'].mean()
            st.metric("Average Health Score", f"{avg_health_score:.1f}/100")
            
            # BMI distribution
            bmi_counts = family_df['status'].value_counts()
            fig_bmi = px.pie(values=bmi_counts.values, names=bmi_counts.index, 
                           title="BMI Status Distribution")
            st.plotly_chart(fig_bmi, use_container_width=True)
        
        with col2:
            # Water intake comparison
            fig_water = px.bar(family_df, x='name', y='water_intake', 
                             title="Daily Water Intake by Family Member")
            st.plotly_chart(fig_water, use_container_width=True)
        
        # Individual member details
        st.subheader("👤 Family Member Details")
        
        for i, member in enumerate(st.session_state.family_members):
            with st.expander(f"👤 {member['name']} ({member['age']} years, {member['gender']})"):
                col1, col2, col3 = st.columns(3)
                
                with col1:
                    st.write(f"**BMI:** {member['bmi']:.2f} ({member['status']})")
                    st.write(f"**Height:** {member['height']} cm")
                    st.write(f"**Weight:** {member['weight']} kg")
                
                with col2:
                    st.write(f"**Health Score:** {member['health_score']}/100")
                    st.write(f"**Water Intake:** {member['water_intake']} glasses/day")
                    st.write(f"**Last Checkup:** {member['last_checkup']}")
                
                with col3:
                    # Vaccination schedule for children
                    if member['age'] < 18:
                        age_months = member['age'] * 12
                        vaccines = get_vaccination_schedule(age_months)
                        st.write("**Due Vaccines:**")
                        for vaccine in vaccines:
                            st.write(f"• {vaccine}")
                    
                    # Action buttons
                    if st.button(f"🗑️ Remove {member['name']}", key=f"remove_{i}"):
                        st.session_state.family_members.remove(member)
                        st.rerun()
    else:
        st.info("👥 No family members added yet. Use the Health Dashboard to add family members.")

# Reminders Page
elif page == "🔔 Reminders":
    st.header("🔔 Health Reminders")
    
    # Add new reminder
    st.subheader("➕ Add New Reminder")
    with st.form("reminder_form"):
        col1, col2 = st.columns(2)
        
        with col1:
            reminder_name = st.text_input("Name")
            reminder_type = st.selectbox("Reminder Type", [
                "vaccination", "checkup", "water", "exercise", "medicine"
            ])
        
        with col2:
            due_date = st.date_input("Due Date", min_value=date.today())
            description = st.text_area("Description (optional)")
        
        if st.form_submit_button("➕ Add Reminder"):
            if reminder_name:
                reminder = create_reminder(reminder_name, reminder_type, due_date.isoformat(), description)
                save_reminder(reminder)
                st.success("✅ Reminder added successfully!")
            else:
                st.error("Please enter a name for the reminder.")
    
    # Display upcoming reminders
    st.subheader("📅 Upcoming Reminders")
    upcoming_reminders = get_upcoming_reminders(30)  # Next 30 days
    
    if upcoming_reminders:
        for reminder in upcoming_reminders:
            days_until = reminder["days_until"]
            urgency_color = "🔴" if days_until <= 1 else "🟡" if days_until <= 3 else "🟢"
            
            st.markdown(f'''
            <div class="reminder-card">
                <strong>{urgency_color} {reminder["name"]}</strong><br>
                <strong>Type:</strong> {reminder["type"].title()}<br>
                <strong>Due:</strong> {reminder["due_date"]} ({days_until} days from now)<br>
                <strong>Description:</strong> {reminder.get("description", "No description")}
            </div>
            ''', unsafe_allow_html=True)
    else:
        st.info("📅 No upcoming reminders in the next 30 days.")

# Health Education Page
elif page == "🎓 Health Education":
    st.header("🎓 Health Education & Awareness")
    
    # Load health education data
    try:
        education_df = pd.read_csv("data/health_data.csv", on_bad_lines="skip")
        
        # Category filter
        categories = ["All"] + list(education_df['category'].unique())
        selected_category = st.selectbox("Select Category", categories)
        
        if selected_category != "All":
            filtered_df = education_df[education_df['category'] == selected_category]
        else:
            filtered_df = education_df
        
        # Display Q&A
        st.subheader("❓ Frequently Asked Questions")
        
        for _, row in filtered_df.iterrows():
            with st.expander(f"❓ {row['question']}"):
                st.write(f"**Answer:** {row['answer']}")
        
        # Local language tips
        st.subheader("🌍 Health Tips in Local Language")
        language = st.selectbox("Select Language", ["English", "Hindi"])

# Step 2: Call function dynamically
        st.subheader("🌍 Health Tips in Local Language")
        col1, col2 = st.columns(2)

    # English
        with col1:
            st.write("**English Tips**")
            st.markdown("""
            - **Nutrition:** Eat pulses, green vegetables, fruits, and milk daily. Avoid junk food.  
            - **Hygiene:** Wash hands with soap before eating and after using the toilet.  
            - **Water:** Drink at least 8 glasses of clean water daily.  
            - **Exercise:** Walk or do light exercise for 30 minutes daily.  
            - **Vaccination:** Ensure children get timely vaccines to prevent diseases.
            """)

    # Hindi
        with col2:
            st.write("**हिंदी सुझाव**")
            st.markdown("""
            - **पोषण:** रोजाना दाल, हरी सब्जियां, फल और दूध खाएं। जंक फूड से बचें।  
            - **स्वच्छता:** खाने से पहले और शौचालय के बाद साबुन से हाथ धोएं।  
            - **पानी:** रोजाना कम से कम 8 गिलास साफ पानी पिएं।  
            - **व्यायाम:** रोजाना 30 मिनट टहलें या हल्का व्यायाम करें।  
            - **टीकाकरण:** बच्चों को समय पर टीके लगवाएं ताकि बीमारियों से बचा जा सके।
            """)
    except FileNotFoundError:
        st.error("Health education data not found. Please ensure health_data.csv exists.")

# Voice Assistant Page
elif page == "🎙️ Voice Assistant":
    st.header("🎙️ Voice Assistant")
    
    st.markdown('<div class="voice-section">', unsafe_allow_html=True)
    
    st.subheader("🗣️ Interactive Voice Assistant")
    st.write("Ask me anything about health, nutrition, hygiene, or vaccinations!")
    
    col1, col2 = st.columns(2)
    
    with col1:
        if st.button("🎤 Start Listening", use_container_width=True):
            st.info("🎤 Listening... Speak now!")
            user_query = voice_assistant.listen()
            if user_query:
                st.write(f"**You said:** {user_query}")
                response = process_voice_query(user_query)
                st.write(f"**Assistant:** {response}")
                
                # Speak the response
                if st.button("🔊 Speak Response"):
                    voice_assistant.speak(response)
    
    with col2:
        # Text-based chat
        st.subheader("💬 Text Chat")
        user_input = st.text_input("Type your health question:")
        
        if st.button("Send", use_container_width=True):
            if user_input:
                response = process_voice_query(user_input)
                st.write(f"**Assistant:** {response}")
    
    st.markdown('</div>', unsafe_allow_html=True)
    
    # Voice commands help
    st.subheader("🎯 Voice Commands")
    st.write("Try saying:")
    commands = [
        "Hello" or "Namaste",
        "Health tip",
        "Water advice", 
        "Vaccination schedule",
        "Hygiene tips",
        "Nutrition advice"
    ]
    
    for cmd in commands:
        st.write(f"• \"{cmd}\"")

# Health Trends Page
elif page == "📈 Health Trends":
    st.header("📈 Health Trends & Analytics")
    
    if st.session_state.family_members:
        family_df = pd.DataFrame(st.session_state.family_members)
        
        # Health score trends
        st.subheader("📊 Health Score Trends")
        fig_scores = px.bar(family_df, x='name', y='health_score', 
                           title="Health Scores by Family Member",
                           color='health_score',
                           color_continuous_scale='RdYlGn')
        st.plotly_chart(fig_scores, use_container_width=True)
        
        # BMI vs Water Intake scatter plot
        st.subheader("💧 BMI vs Water Intake")
        fig_scatter = px.scatter(family_df, x='water_intake', y='bmi', 
                               size='health_score', color='status',
                               hover_data=['name', 'age'],
                               title="Water Intake vs BMI by Health Status")
        st.plotly_chart(fig_scatter, use_container_width=True)
        
        # Age distribution
        st.subheader("👥 Age Distribution")
        fig_age = px.histogram(family_df, x='age', nbins=10, 
                             title="Family Age Distribution")
        st.plotly_chart(fig_age, use_container_width=True)
        
    else:
        st.info("📊 Add family members to see health trends and analytics.")

# Footer
st.markdown("---")
st.markdown("""
<div style="text-align: center; color: #666; padding: 1rem;">
    <p>⚕️ Rural Health Tracker - Promoting Preventive Healthcare & Awareness</p>
    <p>Built with ❤️ for rural communities</p>
</div>
""", unsafe_allow_html=True)
